from django.apps import AppConfig


class ResponseioConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'responseio'
